<?php
$db_host = "m1.lifezeeds.me";
$db_user = "web";
$db_password = "web-final";
$database = "watchstore";
$con = mysqli_connect($db_host, $db_user, $db_password, $database);

                if(!$con){
                    die("connect_error");
                }
                else{
                   // echo "connected";
                }

