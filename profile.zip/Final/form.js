var FullName  = document.getElementById("txtFullName").value;
var Email = document.getElementById("txtEmail").value;
var gender = document.getElementById("txtGender").value;
var dateOfBirth = document.getElementById("txtDateOfBirth").value;
var PhoneNo1 = document.getElementById("PhoneNo1").value;
var AdditionalPhoneNo = document.getElementById("AdditionalPhoneNo").value;
var Address = document.getElementById("txtAddress").value;
var City = document.getElementById("txtCity").value;
var State = document.getElementById("txtState").value;
var ZipCode = document.getElementById("txtZip").value;



